package integradorvehiculos.Interfaces;

public interface Electrico {
    
    public void cargarEnergia();
    
}
