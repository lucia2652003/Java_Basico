
package integradorvehiculos.Interfaces;


public interface Combustion {
    
    public void recargarCombustible();
    
}
