
package com.mycompany.jpa;

import com.mycompany.jpa.persistencia.ControladoraPersistencia;

public class Jpa {

    public static void main(String[] args) {
        
        ControladoraPersistencia controlPersis = new ControladoraPersistencia();
        
        
    }
}
