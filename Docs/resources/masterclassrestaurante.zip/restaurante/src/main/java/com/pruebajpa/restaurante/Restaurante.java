package com.pruebajpa.restaurante;

import com.pruebajpa.restaurante.logica.Controladora;
import com.pruebajpa.restaurante.logica.Platillo;
import java.util.List;

public class Restaurante {

    public static void main(String[] args) {
        
        Controladora control = new Controladora();
        
        
        /*Proceso de altas*/
        System.out.println("---------REALIZANDO LAS ALTAS----------");
        
        Platillo plat1 = new Platillo (1, "Milanesa a la napolitana", "esta es la receta",15.0);
        control.crearPlatillo(plat1);
       
       Platillo plat2 = new Platillo (2, "Fideos con salsa", "esta es la receta",8.0);
        control.crearPlatillo(plat2);
        control.crearPlatillo(new Platillo(3, "Paella", "receta de paella",25.0));
        
        
        /*Proceso de eliminación*/
        System.out.println("---------ELIMINANDO REGISTRO 2----------");
        int idEliminar = 2;
        control.eliminarPlatillo(idEliminar);
   
        /*Proceso de edición*/
        System.out.println("---------EDITANDO REGISTRO 3----------");
        int idEditar = 3;
        Platillo platEdit = control.buscarPlatillo(idEditar);
        platEdit.setPrecio(30.0);
        
        control.editarPlatillo(platEdit);
        
        /*Proceso de lectura*/
        System.out.println("---------LISTA FINAL DE PLATILLOS----------");
        List<Platillo> listaPlatillos = control.traerPlatillos();
        
        for(Platillo plat : listaPlatillos) {
            System.out.println(plat.toString());
        }
        
        
        
    }
}
